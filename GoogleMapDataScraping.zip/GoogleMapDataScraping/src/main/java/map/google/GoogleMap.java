package map.google;

import java.io.IOException;

import map.google.businessl.MainLogic;

public class GoogleMap {

	public static void main(String[] args) throws InterruptedException, IOException {
		MainLogic main = new MainLogic();
		
		main.setup();
		main.toLogin();

	}

}
