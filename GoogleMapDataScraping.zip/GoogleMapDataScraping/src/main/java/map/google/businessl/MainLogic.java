package map.google.businessl;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import map.google.util.GoogleMapUtil;

public class MainLogic {

	GoogleMapUtil util = new GoogleMapUtil();
	WebDriver driver;
	ChromeOptions opt;
	

	String outfilename=".\\file\\outputlink.xlsx";
	String outsheetName= "sheet1";
	String sheetName= "sheet2";
	
	
	String xlistLink = "//a[@role='link']";
	String xshopName = "//h2[@data-attrid='title']";
	String xCat = "//div[contains(@data-attrid,'attribute list')]/div[2]/div/span | //div[contains(@data-attrid,'line summary')]";
	String xCat2 = "(//div[contains(@data-attrid,'attribute list')]/div[2]/div/span | //div[contains(@data-attrid,'line summary')])[2]";
	String xaddress = "//div[contains(@data-attrid,'address')]/div/div/span[2]";
	String xPhNo = "//span[contains(@aria-label,'Call phone number')]";
	String xwebsite = "//div[contains(text(),'Website')]/parent::a";
	String xclosePopUp = "(//div[@aria-label='Close'])[1]";
	String xnextCheck ="//a[@id='pnnext']/span[2]";
	String xnextClick = "//a[@id='pnnext']";
	
	
	public void toLogin() throws InterruptedException, IOException {
		List<WebElement> links = driver.findElements(By.xpath(xlistLink));
//		ArrayList<String> href = new ArrayList<String>();
		
		for(WebElement link:links) {
			link.click();
			Thread.sleep(2000);
			
			int row = util.getRowCount(outfilename, outsheetName);
			row++;
			
			//Shop Name
			try {
				String ShopName= driver.findElement(By.xpath(xshopName)).getText();
				util.setCellData(outfilename, outsheetName, row, 0, ShopName);
				System.out.println("Shop Name: "+ShopName);
			} catch (Exception e) {
				System.out.println("Shop Name Not Found");
			}
			
			//Category 
			try {
				String cat= driver.findElement(By.xpath(xCat)).getText();
				if (cat.contains("$")) {
					String category= driver.findElement(By.xpath(xCat2)).getText();
					util.setCellData(outfilename, outsheetName, row, 1, category);
					System.out.println("Category: "+category);
				}else {
					String category2 = driver.findElement(By.xpath(xCat)).getText();
					util.setCellData(outfilename, outsheetName, row, 1, category2);
					System.out.println("Category: "+category2);
				}
				
				
			} catch (Exception e) {
				System.out.println("Category Not Found");
			}
			
			//Address
			try {
				String address= driver.findElement(By.xpath(xaddress)).getText();
				util.setCellData(outfilename, outsheetName, row, 2, address);
				System.out.println("Address: "+address);
			} catch (Exception e) {
				System.out.println("Address Not Found");
			}
			
			//Phone Number
			try {
				String phone= driver.findElement(By.xpath(xPhNo)).getText();
				util.setCellData(outfilename, outsheetName, row, 3, phone);
				System.out.println("Phone No: "+phone);
			} catch (Exception e) {
				System.out.println("Phone Number Not Found");
			}
			
			//Website URL
			try {
				String website= driver.findElement(By.xpath(xwebsite)).getAttribute("href");
				util.setCellData(outfilename, outsheetName, row, 4, website);
				System.out.println("Website URL: "+website);
			} catch (Exception e) {
				System.out.println("Website Not Found");
			}
			
			//Page Close
			try {
				driver.findElement(By.xpath(xclosePopUp)).click();
				System.out.println("PoPUp Page Close\r\n"
						+ "\r\n");
			} catch (Exception e) {
				System.out.println("PoPUp Page Not Close/n/r"+"/n/r");
				driver.findElement(By.xpath(xclosePopUp)).click();
				System.out.println("PoPUp Page Close/n/r"+"/n/r");
			}
		}
		//Frist Page Complete
		//Start Next page Loop
		String next = driver.findElement(By.xpath(xnextCheck)).getText();
		
		while (next!=null || next.length()!=0) {
			driver.findElement(By.xpath(xnextClick)).click();
			Thread.sleep(5000);
			List<WebElement> linkx = driver.findElements(By.xpath(xlistLink));
			
			for(WebElement linkr:linkx) {
				linkr.click();
				Thread.sleep(2000);
				int rowx = util.getRowCount(outfilename, outsheetName);
				rowx++;
				
				//Shop Name
				try {
					String ShopName= driver.findElement(By.xpath(xshopName)).getText();
					util.setCellData(outfilename, outsheetName, rowx, 0, ShopName);
					System.out.println("Shop Name: "+ShopName);
				} catch (Exception e) {
					System.out.println("Shop Name Not Found");
				}
				
				//Category 
				try {
					String category= driver.findElement(By.xpath(xCat)).getText();
					util.setCellData(outfilename, outsheetName, rowx, 1, category);
					System.out.println("Category: "+category);
				} catch (Exception e) {
					System.out.println("Category Not Found");
				}
				
				//Address
				try {
					String address= driver.findElement(By.xpath(xaddress)).getText();
					util.setCellData(outfilename, outsheetName, rowx, 2, address);
					System.out.println("Address: "+address);
				} catch (Exception e) {
					System.out.println("Address Not Found");
				}
				
				//Phone Number
				try {
					String phone= driver.findElement(By.xpath(xPhNo)).getText();
					util.setCellData(outfilename, outsheetName, rowx, 3, phone);
					System.out.println("Phone No: "+phone);
				} catch (Exception e) {
					System.out.println("Phone Number Not Found");
				}
				
				//Website URL
				try {
					String website= driver.findElement(By.xpath(xwebsite)).getAttribute("href");
					util.setCellData(outfilename, outsheetName, rowx, 4, website);
					System.out.println("Website URL: "+website);
				} catch (Exception e) {
					System.out.println("Website Not Found");
				}
				
				//Page Close
				try {
					driver.findElement(By.xpath(xclosePopUp)).click();
					System.out.println("PoPUp Page Close\r\n"
							+ "\r\n");
				} catch (Exception e) {
					System.out.println("PoPUp Page Not Close/n/r"+"/n/r");
					driver.findElement(By.xpath(xclosePopUp)).click();
					System.out.println("PoPUp Page Close/n/r"+"/n/r");
				}
			}
		}
		
	}
	
	
	public void setup() {
		System.out.println("I setup ");
		
		System.setProperty("webdriver.chrome.driver", "E:\\Java Current Project\\LinkedinProfileScraper\\devtools\\chromedriver.exe");
		opt = new ChromeOptions();
		opt.setExperimentalOption("debuggerAddress", "localhost:9222");
		
		driver = new ChromeDriver(opt);
//		driver.get(appUrl);
		driver.manage().window().maximize();
	}
	
	
}















