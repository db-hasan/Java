package com.emailvalidetor.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class TestUtil {

//	public static void String[] getMX(String hostname) throws NamingException {
//		
//		
//	}
	
}
