package com.tajnur;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws IOException {
		
		int len = 32;
		
		for (int i = 1; i < len; i+=2) {
			System.out.println(i);
		}
		
		
		
		
		
//		FileWriter file;
//		
//		
//		file = new FileWriter(".//file//search1.txt");
//		
//		System.out.println("file Create");
//		file.write("My name is Tajnur");
//		file.close();
//		
		
	}

}
