package com.inboxcheck.main;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GmailBoday {


	WebDriver driver;
//	ChromeOptions options;
	FirefoxOptions options;
	
	String appUrl="https://mail.google.com/";
	String filename=".\\file\\myinput.xlsx";
	String sheetName= "sheet1";
	
	@Test
	public void logof() throws InterruptedException {
		driver.findElement(By.name("identifier")).sendKeys("b2bleadstore@gmail.com",Keys.ENTER);
//		driver.findElement(By.xpath("//*[@id=\'identifierNext\']/div/button/div[2]")).click();
		 
		
		Thread.sleep(3000);
		  
		try {
			WebElement elePassword=driver.findElement(By.xpath("//input[@type='password']"));
			elePassword.sendKeys("taj94686TT",Keys.ENTER);
		} catch (Exception e) {
			WebElement elePassword=driver.findElement(By.xpath("//input[@type='password']"));
			elePassword.sendKeys("taj94686TT",Keys.ENTER);
		}
		Thread.sleep(5000);

	}
	
	
	@Test(dataProvider = "userdata")
	public void toLogin(String name, String email) throws InterruptedException, IOException {
		
		Thread.sleep(3000);
		//click on compose
		driver.findElement(By.xpath("//div[contains(text(),'Compose')]")).click();
		  
		  //Open Compose box and add To, Subject, Body Text
		  WebElement sender=driver.findElement(By.xpath("//textarea[@name='to']"));
		  sender.sendKeys(email);
		  sender.sendKeys(Keys.ENTER);
		  
		  String subject = "Increase Your Sales Revenue in 2021";
		  WebElement subj=driver.findElement(By.xpath("//input[@name='subjectbox']"));
		  subj.click();
		  subj.sendKeys(subject);
		  
		  try {
			  WebElement bodytest=driver.findElement(By.xpath("//div[@role='textbox']"));
			  bodytest.click();
			  bodytest.sendKeys("Hey "+name+",\r\n"
			  		+ "This year we made a plan to full your order books and the �pipeline� with new prospects for your products is always filled to the limit with new, really interested potential customers.\r\n"
			  		+ "\r\n"
			  		+ "The sales pipeline is constantly being replenished with new contacts, exactly you imagine with the potential customer's list for your product.\r\n"
			  		+ "\r\n"
			  		+ "You and your company have invested a lot of money in Social Media Promotion, SEO, Ads, etc. What if we reach your product to the potential customer?\r\n"
			  		+ "\r\n"
			  		+ "Yes, we are here to help you with B2B Lead Generation service:\r\n"
			  		+ "1).  Potential Customers email list building\r\n"
			  		+ "2).  we will send them your customized message\r\n"
			  		+ "3).  Of course, we will give you an acceptable price\r\n"
			  		+ "\r\n"
			  		+ "Here is your service list for you: https://cutt.ly/nWhxNKY\r\n"
			  		+ "\r\n"
			  		+ "Take a look and if you have any questions or would like to set up an intro order, my contact information is at the end of the massage. I am looking forward to hearing from you.\r\n"
			  		+ "\r\n"
			  		+ "Thanks �\r\n"
			  		+ "\r\n"
			  		+ "Tajnur Rahman\r\n"
			  		+ "Lead Generation specialist\r\n"
			  		+ "Whatsapp: +088-01312136602\r\n"
			  		+ "Email: tajnur779@gmail.com\r\n"
			  		+ "\r\n"
			  		+ "�B2B Lead Store�\r\n"
			  		+ "");
		} 
		  catch (NoSuchElementException e) 
		  {
			  WebElement bodytest=driver.findElement(By.xpath("//div[@role='textbox']"));
			  bodytest.click();
			  bodytest.sendKeys("Hey "+name+",\r\n"
				  		+ "This year we made a plan to full your order books and the �pipeline� with new prospects for your products is always filled to the limit with new, really interested potential customers.\r\n"
				  		+ "\r\n"
				  		+ "The sales pipeline is constantly being replenished with new contacts, exactly you imagine with the potential customer's list for your product.\r\n"
				  		+ "\r\n"
				  		+ "You and your company have invested a lot of money in Social Media Promotion, SEO, Ads, etc. What if we reach your product to the potential customer?\r\n"
				  		+ "\r\n"
				  		+ "Yes, we are here to help you with B2B Lead Generation service:\r\n"
				  		+ "1).  Potential Customers email list building\r\n"
				  		+ "2).  we will send them your customized message\r\n"
				  		+ "3).  Of course, we will give you an acceptable price\r\n"
				  		+ "\r\n"
				  		+ "Here is your service list for you: https://cutt.ly/nWhxNKY\r\n"
				  		+ "\r\n"
				  		+ "Take a look and if you have any questions or would like to set up an intro order, my contact information is at the end of the massage. I am looking forward to hearing from you.\r\n"
				  		+ "\r\n"
				  		+ "Thanks �\r\n"
				  		+ "\r\n"
				  		+ "Tajnur Rahman\r\n"
				  		+ "Lead Generation specialist\r\n"
				  		+ "Whatsapp: +088-01312136602\r\n"
				  		+ "Email: tajnur779@gmail.com\r\n"
				  		+ "\r\n"
				  		+ "�B2B Lead Store�\r\n"
				  		+ "");
		}
		  
		  Thread.sleep(2000);
		  
		  //Click on Send Button
		  driver.findElement(By.xpath("//div[@class='T-I J-J5-Ji aoO v7 T-I-atl L3']")).click();
		  
		  LocalDateTime myDate = LocalDateTime.now();
		  DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		  
		  String format = myDate.format(dateFormat);
		  int row = 1;
		  row++;
		  
		  mailUtl.setCellData(filename, sheetName, row, 2, format);
		  
		  
	}
	
	
	@BeforeClass
	public void setup() {
		
		System.out.println("I setup ");
		
		WebDriverManager.firefoxdriver().setup();
		options=new FirefoxOptions();
		options.addArguments("--ignore-certificate-error");
		driver=new FirefoxDriver();
		
		driver.get(appUrl);
		driver.manage().window().maximize();
		
	}
	
	@AfterClass
	public void tearDown() {
		System.out.println("tear down....");
		
		if (driver != null) {
			driver.close();
			driver.quit();
		}
		
	}
	
	@DataProvider(name="userdata")
	public String[][] getData() throws IOException{
		
		System.out.println("In Get data method....");
		
		int rowcount=mailUtl.getRowCount(filename, sheetName);
		System.out.println("Row Count is: "+rowcount);
		
		
		int cellcount = mailUtl.getCellData(filename, sheetName, 0);
		System.out.println("Cell Count is: "+cellcount);
		
		String loginData[][]=new String[rowcount][cellcount];
		
		for (int row = 1; row <= rowcount; row++) {
			
			
			for (int cell = 0; cell < cellcount; cell++) {
				loginData[row-1][cell] = mailUtl.getCellData(filename, sheetName, row, cell);
				
			}
			
		}
		return loginData;
	}

	
}
